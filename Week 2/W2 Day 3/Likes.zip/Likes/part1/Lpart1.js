var x = document.querySelector(".c2 p");
var count = 3;
function increment() {
    count++;
    x.innerText = count;
}





