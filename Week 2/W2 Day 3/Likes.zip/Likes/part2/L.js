
var x = document.querySelector(".c2 p");
var y = document.querySelector(".c3 p");
var z = document.querySelector(".c4 p");
var count1 = 9
var count2 = 12
var count3 = 9
function increment1() {
    count1++;
    x.innerText = count1;
}

function increment2() {
    count2++;
    y.innerText = count2;
}


function increment3() {
    count3++;
    z.innerText = count3;
}


