console.log("page loaded...");
function over(elem) {
    elem.play();
}
function out(elem) {
    elem.pause();
}
