var product = 1;
for(var i=1; i<13; i++) {
    product *= i;
}
console.log(product);