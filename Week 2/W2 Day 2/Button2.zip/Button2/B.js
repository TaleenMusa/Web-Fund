function liked(id) {
    alert("Ninja was liked")
    
}
function logout(element) {
    element.innerText = "Logout";
}
function remv(element) {
    element.remove();
}